# Simple addition function
def add(a, b):
    return a + b

result = add(3, 5)
print "The result is:", result
