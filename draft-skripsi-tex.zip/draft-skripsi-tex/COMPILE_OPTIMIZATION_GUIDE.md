# Compilation Optimization Guide for bab4.tex

## Problem
Overleaf compile timeout due to large/high-resolution images and complex content in bab4.tex.

## Solutions (Choose ONE method based on your needs)

### Method 1: Draft Mode (FASTEST - Recommended for editing)
Uncomment this line at the top of bab4.tex:
```latex
\usepackage[draft]{graphicx}
```
**Effect**: Shows gray boxes with filenames instead of actual images
**Use case**: When editing text content

### Method 2: Placeholder Mode (FAST)
Uncomment these lines at the top of bab4.tex:
```latex
\newcommand{\draftgraphics}[2][]{{\footnotesize [Figure: #2]}}
\renewcommand{\includegraphics}{\draftgraphics}
```
**Effect**: Shows text placeholders instead of images
**Use case**: When reviewing document structure

### Method 3: Selective Figure Compilation (MODERATE)
Uncomment and modify these lines at the top of bab4.tex:
```latex
\newif\iffastcompile
\fastcompiletrue  % Change to \fastcompilefalse for full compilation
```
Then wrap problematic figures with:
```latex
\iffastcompile
% Fast compile: show placeholder
{\footnotesize [Figure placeholder]}
\else
% Full compile: show actual figure
\includegraphics[...]{...}
\fi
```

### Method 4: Image Optimization (Applied automatically)
- Reduced image sizes from `width=\textwidth` to `width=0.8-0.9\textwidth`
- Optimized subfigure layouts
- Reduced PDF figure sizes

## Already Applied Optimizations

✅ **Image Size Reduction**:
- Confusion matrices: `\textwidth` → `0.85\textwidth`
- Feature importance plots: `\textwidth` → `0.9\textwidth`
- ROC curves: `\textwidth` → `0.85\textwidth`
- Timing patterns: `0.9\textwidth` → `0.75\textwidth`

✅ **Figure Optimization**:
- 13 active figures optimized
- Several complex figures already commented out
- Subfigure layouts streamlined

## Quick Fix for Immediate Use

1. **Open bab4.tex**
2. **Find line 6** (after the chapter declaration)
3. **Uncomment this line**:
   ```latex
   \usepackage[draft]{graphicx}
   ```
4. **Compile** - should be much faster
5. **When ready for final version**, comment it back out

## Alternative: Split Chapter Approach

If timeouts persist, consider splitting bab4.tex into smaller files:

```latex
% In main bab4.tex
\input{bab4-part1-data}
\input{bab4-part2-models}  
\input{bab4-part3-analysis}
\input{bab4-part4-discussion}
```

This allows compiling sections individually.

## Image Optimization Tips

1. **Convert PNG to PDF** for vector graphics when possible
2. **Reduce image resolution** for screenshots (300 DPI max)
3. **Compress large files** before uploading to Overleaf
4. **Use JPG for photos**, PDF for plots/diagrams

## Emergency Compilation Strategy

If all else fails:
1. Use Method 1 (draft mode) for editing
2. Temporarily comment out 50% of figures
3. Compile in sections
4. Re-enable figures one by one to identify problematic ones

Remember: The content is preserved - these are just compilation optimizations! 